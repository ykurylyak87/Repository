# -*- coding: utf- 8 -*-

d_artagnan = u"\tМеня зовут д'Артаньян."
athos = u"Эта строка\nразделена на две."
porthos = u"Я \\ - \\ мушкетер!"

aramis = u"""
Подсказки:
\t* Граф из Гаскони
\t* Связан с Миледи
\t* Барон\n\t* Генерал Ордена
"""

print d_artagnan
print athos
print porthos
print aramis