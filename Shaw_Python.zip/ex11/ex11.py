# -*- coding: utf- 8 -*-

print u"Сколько тебе лет?",
age = raw_input()
print u"Каков твой рост?",
height = raw_input()
print u"Сколько ты весишь?",
weight = raw_input()

print u"Итак, тебе %r лет, в тебе %r см роста и %r кг веса." % (
age, height, weight)